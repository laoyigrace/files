<div id="shang" style="display: none; position: fixed; opacity: 1; z-index: 11000; left: 50%; margin-left: -125px; top: 1px;"> 
	<div class="shang-main"> 
		<h4>您可以选择一种方式赞助本站</h4> 
		<form accept-charset="GBK" action="https://shenghuo.alipay.com/send/payment/fill.htm" method="POST" target="_blank">
				<input name="optEmail" type="hidden" value="yigujin@qq.com"> 
				<input name="payAmount" type="hidden" value="0"> 
				<input id="title" name="title" type="hidden" value="赞助主题设计者懿古今"> 
				<input name="memo" type="hidden" value="《<?php the_title(); ?>》写得很给力，本大爷有赏！"> <input title="点击此按钮赞助本站" name="pay" src="<?php bloginfo('template_directory'); ?>/images/alipay.png" type="image" value="赞助本站"> 
		</form> 
		<img title="赞助本站" src="<?php bloginfo('template_directory'); ?>/images/shangyigujin.png"> 
	</div>
</div>