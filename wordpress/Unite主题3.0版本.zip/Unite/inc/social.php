<div id="social">
	<div class="social-main">
		<span class="like">
	        <a href="#shang" id="shang-main-p" title="赞助本站">朕要赏赐&nbsp;&nbsp;&nbsp;</a> 
		</span>
		<span class="shang-p">or</span>
		<span class="share-s"><a href="#share" id="share-main-s">&nbsp;&nbsp;&nbsp;朕要分享</a></span>
		<div class="clear"></div>
	</div>
</div>


