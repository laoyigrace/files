<div id="slideshow">	
	<ul id="slider">
		<?php echo stripslashes(get_option('ygj_hdp_dm')); ?>
	</ul>	
</div>	