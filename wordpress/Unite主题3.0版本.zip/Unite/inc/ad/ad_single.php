<div id="ad_sg" class="ad-pc">
<?php echo stripslashes( get_option('ygj_single_ad') ); ?>
</div>