	<div id="ad-dhl" class="ad-pc">
		<?php echo stripslashes(get_option('ygj_addd_c')); ?>
	</div>	