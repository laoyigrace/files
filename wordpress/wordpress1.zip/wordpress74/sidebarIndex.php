					<div class="sideBar rightFloat">
						<div class="mod">
							<h3 class="sideTitle">关注我们</h3>
							<div class="textwidget">
								<ul>
									<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="现代新浪微博" href="#">
												<img alt="现代新浪微博" src="<?php bloginfo('template_directory'); ?>/images/ico/sina.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="#">运营笔记新浪微博</a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
    								<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="现代新浪微博" href="#">
												<img alt="现代新浪微博" src="<?php bloginfo('template_directory'); ?>/images/ico/qzone.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="#">运营笔记腾讯空间</a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
								</ul>
							</div>
						</div>
						<div class="mod">
							<h3 class="sideTitle">活动征集 </h3>
							<div class="textwidget">
								<div class="adImg">
									<a target="_blank" href="#">
										<img width="100%" src="<?php bloginfo('template_directory'); ?>/images/ad/ad-1.jpg">
									</a>
								</div>
							</div>
						</div>
						<div class="mod">
							<h3 class="sideTitle">作家推荐</h3>
							<div class="textwidget">
								<ul>
									<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="用户" href="#">
												<img alt="用户头像" src="<?php bloginfo('template_directory'); ?>/images/ico/user.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="<?php echo bloginfo('url').'/author/';the_author_meta( 'user_login', 1 ); ?>"><?php the_author_meta( 'display_name', 2 ); ?></a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
    								<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="现代新浪微博" href="#">
												<img alt="用户头像" src="<?php bloginfo('template_directory'); ?>/images/ico/user.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="#">欢迎加入</a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
    								<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="现代新浪微博" href="#">
												<img alt="用户头像" src="<?php bloginfo('template_directory'); ?>/images/ico/user.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="#">欢迎加入</a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
    								<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="现代新浪微博" href="#">
												<img alt="用户头像" src="<?php bloginfo('template_directory'); ?>/images/ico/user.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="#">欢迎加入</a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
    								<li>
      									<div class="clear">
											<a class="socialIcoImg" target="_blank" title="现代新浪微博" href="#">
												<img alt="用户头像" src="<?php bloginfo('template_directory'); ?>/images/ico/user.png">
											</a>
        									<div class="socialText">
          										<p>
													<a target="_blank" href="#">欢迎加入</a>
												</p>
          										<div author="@hanhaoniaoqy">与超过106,1790人一起，关注@运营笔记。</div>
        									</div>
      									</div>
    								</li>
								</ul>
							</div>
						</div>
						<div class="mod">
							<h3 class="sideTitle">合作伙伴
								 </h3>
							<div class="textwidget">
								<div class="adImg">
									<a target="_blank" href="#">
										<img width="100%" src="<?php bloginfo('template_directory'); ?>/images/ad/ad-2.jpg">
									</a>
								</div>
								<div class="adImg">
									<a target="_blank" href="#">
										<img width="100%" src="<?php bloginfo('template_directory'); ?>/images/ad/ad-2.jpg">
									</a>
								</div>
								<div class="adImg">
									<a target="_blank" href="#">
										<img width="100%" src="<?php bloginfo('template_directory'); ?>/images/ad/ad-2.jpg">
									</a>
								</div>
							</div>
						</div>
					</div>
